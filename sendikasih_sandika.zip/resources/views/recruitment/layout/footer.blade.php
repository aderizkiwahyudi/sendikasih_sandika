<footer>
    <p>Yayasan Sendikasih Sandika © 2022</p>
</footer>