<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div id="content-wrapper bg-white">

        <?php if (isset($component)) { $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminAside::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminAside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630)): ?>
<?php $component = $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630; ?>
<?php unset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630); ?>
<?php endif; ?>

        <main>

            <?php if (isset($component)) { $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminNavigation::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminNavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e)): ?>
<?php $component = $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e; ?>
<?php unset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e); ?>
<?php endif; ?>
                
            <div class="content">
                <div class="row">
                    <div class="col-md-6">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                Terdapat Kesalahan :
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <h4>Pengaturan Website</h4>
                            <div>
                                
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="" class="mb-2">Facebook</label>
                                    <input type="text" name="facebook" id="facebook" class="form-control" value="<?php echo e($web->facebook); ?>" placeholder="Masukan url instagram"/>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="" class="mb-2">Twitter</label>
                                    <input type="text" name="twitter" id="twitter" class="form-control" value="<?php echo e($web->twitter); ?>" placeholder="Masukan url twitter"/>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="" class="mb-2">Youtube</label>
                                    <input type="text" name="youtube" id="youtube" class="form-control" value="<?php echo e($web->youtube); ?>" placeholder="Masukan url youtube"/>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="" class="mb-2">Tahun Akademik</label>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <select name="year" id="year" class="form-control">
                                                <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->name); ?>" <?php echo e($web->year_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <select name="semester" id="semester" class="form-control">
                                                <option value="">Belum Ditentukan</option>
                                                <option value="ganjil" <?php echo e($web->year->status == 'Ganjil' ? 'selected' : ''); ?>>Semester Ganjil</option>
                                                <option value="genap" <?php echo e($web->year->status == 'Genap' ? 'selected' : ''); ?>>Semester Genap</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary px-5 w-100">SIMPAN</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </main>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/website/setting.blade.php ENDPATH**/ ?>