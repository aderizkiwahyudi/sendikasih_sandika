<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => ''.e(ucwords(str_replace('-', ' ', Request::segment(2) ?? Request::segment(1)))).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    <section class="breadcrumb">
        <div class="container">
            <h4 class="text-white">
                <?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?>

                <?php echo e(Request::segment(2) ? ucwords(str_replace('-', ' ', Request::segment(2))) : ''); ?>

            </h4>
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="/">Home</a>
                <a class="breadcrumb-item" href="/galeri">Galeri</a>
                <?php echo Request::segment(2) ? '<span class="breadcrumb-item active" href="' . url('berita') . '">' . ucwords(str_replace('-', ' ', Request::segment(2)))  . '</span>' : ''; ?>

            </nav>
        </div>
    </section>
    <?php if(Request::segment(2)): ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.10.4/viewer.min.css" integrity="sha512-OgbWuZ8OyVQxlWHea0T9Bdy1oDhs380WxLMaLZbuitQ/mdntHBPnApxbTebB9N5KoHZd3VMkk3G2cTY563nu5w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.10.4/viewer.min.js" integrity="sha512-2HLzgJH7ZNywnEDB1HqijieFxszStt3QXS8Qk9m/VMUV/asMWlz9PmibHsvWIz9rtKOOr28z8zu1iJ3pf/TTHQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function(){
                const gallery = new Viewer(document.getElementById('images'));
            });
        </script>
    <?php $__env->stopPush(); ?>

    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-3 aside">
                    <?php if (isset($component)) { $__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsideNews::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsideNews::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7)): ?>
<?php $component = $__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7; ?>
<?php unset($__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7); ?>
<?php endif; ?>
                </div>
                <div class="col-md-9">
                    <h2><?php echo e($gallery->title); ?></h2>
                    <p class="info"><?php echo e(tanggal_berita($gallery->created_at)); ?>, ditulis oleh admin</p>
                    <div class="article-text my-3">
                        <?php echo $gallery->content; ?>

                    </div>
                    <div class="row" id="images">
                        <?php $__empty_1 = true; $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-4">
                                <div class="gallery-image-item">
                                    <img src="<?php echo e($photo->url); ?>" alt="<?php echo e($photo->url); ?>" height="100%"/>
                                </div>
                            </div>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Tidak terdapat foto</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php else: ?>
        <section class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 aside">
                        <?php if (isset($component)) { $__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsideNews::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsideNews::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7)): ?>
<?php $component = $__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7; ?>
<?php unset($__componentOriginal1b83710129938794a389f297f0938e9a97b2c0e7); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-9">
                        <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <img src="<?php echo e($item->photos[0]->url); ?>" alt="Gambar" width="100%"/>
                                </div>
                                <div class="col-md-9">
                                    <div class="card-body">
                                        <h4><a href="<?php echo e(url('galeri/' . $item->slug)); ?>"><?php echo e($item->title); ?></a></h4>
                                        <p class="info">
                                            <?php echo e(tanggal_berita($item->created_at)); ?>

                                        </p>
                                        <p><?php echo e(htmlspecialchars(strip_tags(substr($item->content, 0, 150)))); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Belum ada foto</p>
                        <?php endif; ?>
                        <?php echo $galleries->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/gallery.blade.php ENDPATH**/ ?>