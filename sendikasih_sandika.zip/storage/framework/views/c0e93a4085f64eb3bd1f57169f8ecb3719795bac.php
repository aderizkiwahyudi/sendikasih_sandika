<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/academic-dashboard.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeaderAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeaderAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718)): ?>
<?php $component = $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718; ?>
<?php unset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718); ?>
<?php endif; ?>

    <main>
        <div class="container">
            <div class="row">

                <?php if (isset($component)) { $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsideAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsideAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2)): ?>
<?php $component = $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2; ?>
<?php unset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2); ?>
<?php endif; ?>
                
                <div class="col-md-8">
                    <div>
                        <h5 class="mb-1">Pengaturan</h5>
                        <nav class="breadcrumb">
                            <a class="breadcrumb-item" href="#">Home</a>
                            <span class="breadcrumb-item active">Pengaturan</span>
                        </nav>
                    </div>
                    <div class="content-body">
                        <div class="row">
                            <div class="col-md-8">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <strong>Terdapat kesalahan, berikut :</strong>
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="box shadow-sm border">
                                    <form method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="">Nama</label>
                                            <input type="text" class="form-control" placeholder="Masukan nama anda" name="name" value="<?php echo e(Auth::guard('academic')->user()->student->name ??  Auth::guard('academic')->user()->teacher->name ??  Auth::guard('academic')->user()->staff->name ?? ''); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Username</label>
                                            <input type="text" class="form-control" placeholder="Masukan username anda" name="username" value="<?php echo e(Auth::guard('academic')->user()->username); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Email</label>
                                            <input type="email" class="form-control" placeholder="Masukan email anda" name="email" value="<?php echo e(Auth::guard('academic')->user()->email); ?>" disabled/>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Password</label>
                                            <input type="password" class="form-control" placeholder="Masukan password anda" name="password"/>
                                            <small class="text-danger">Kosongkan jika tidak ingin mengubah password</small>
                                        </div>
                                        <div class="form-group mt-3">
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/academic/setting.blade.php ENDPATH**/ ?>