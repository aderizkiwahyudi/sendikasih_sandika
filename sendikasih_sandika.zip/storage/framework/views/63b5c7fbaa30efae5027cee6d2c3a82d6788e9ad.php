<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/academic-dashboard.css')); ?>">
        <style>
            .form-control {
                pointer-events: none;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeaderAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeaderAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718)): ?>
<?php $component = $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718; ?>
<?php unset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718); ?>
<?php endif; ?>

    <main>
        <div class="container">
            <div class="row">

                <?php if (isset($component)) { $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsideAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsideAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2)): ?>
<?php $component = $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2; ?>
<?php unset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2); ?>
<?php endif; ?>
                
                <div class="col-md-8">
                    <div>
                        <h5 class="mb-1">Data Pribadi</h5>
                        <nav class="breadcrumb">
                            <a class="breadcrumb-item" href="#">Home</a>
                            <span class="breadcrumb-item active">Data Pribadi</span>
                        </nav>
                    </div>
                    <div class="content-body">
                        <div class="alert alert-warning">
                            Jika terdapat kesalahan data, silakan hubungi admin untuk melakukan perubahan.
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="box shadow-sm border">
                                    <?php if(Auth::guard('academic')->user()->student): ?>
                                        <?php echo $__env->make('academic.personal.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                                        
                                    <?php elseif(Auth::guard('academic')->user()->teacher): ?>
                                        <?php echo $__env->make('academic.personal.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                                        
                                    <?php else: ?> 
                                        <?php echo $__env->make('academic.personal.staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/academic/personal.blade.php ENDPATH**/ ?>