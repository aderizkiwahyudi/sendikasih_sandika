<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Penerimaan Yayasan Sendikasih Sandika'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/recruitment-dashboard.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppRecruitmentHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-recruitment-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppRecruitmentHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb)): ?>
<?php $component = $__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb; ?>
<?php unset($__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb); ?>
<?php endif; ?>
    
    <main>
        <?php if(Auth::guard('recruitment')->user()->recruitment->result == 0): ?>
            <div class="breadcrumb-container">
                <h1>Pendaftaran</h1>
                <nav class="breadcrumb">
                    <a class="breadcrumb-item" href="#">Dashboard</a>
                    <a class="breadcrumb-item" href="#">Pendaftaran</a>
                    <span class="breadcrumb-item active">Pengisian Biodata</span>
                </nav>
            </div>

            <div class="main-body border">
                <div class="step-container">
                    <ul class="step">
                        <li class="finish">
                            <div class="step-number">✓</div>
                            <div class="step-content">
                                <h4>Pengisian Biodata</h4>
                                <small>Isi Biodata Diri Anda</small>
                            </div>
                            <div class="step-border"></div>
                        </li>
                        <li class="finish">
                            <div class="step-number">✓</div>
                            <div class="step-content">
                                <h4>Unggah Foto</h4>
                                <small>Unggah Foto Anda</small>
                            </div>
                            <div class="step-border"></div>
                        </li>
                        <li class="finish">
                            <div class="step-number">✓</div>
                            <div class="step-content">
                                <h4>Konfirmasi Data</h4>
                                <small>Konfirmasi Data</small>
                            </div>
                            <div class="step-border"></div>
                        </li>
                        <li class="active">
                            <div class="step-number">4</div>
                            <div class="step-content">
                                <h4>Selesai</h4>
                                <small>Pendaftaran Selesai</small>
                            </div>
                        </li>
                    </ul>
                </div>
                <div>
                    <div class="main-form">
                        <h5>Selesai!</h5>
                        <p>Pendaftaran anda telah selesai, data yang anda kirim akan di cek terlebih dahulu. Untuk informasi selanjutnya silakan cari informasi melalui website resmi Yayasan Sendikah Sandika. Terimakasih.</p>
                    </div>
                    <div>
                        <a href="<?php echo e(route('recruitment.finish')); ?>" class="btn btn-primary">Refresh</a>
                    </div>
                </div>

            </div>
        <?php else: ?>
        <div class="breadcrumb-container">
            <h1>Pengumuman</h1>
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="#">Dashboard</a>
                <a class="breadcrumb-item" href="#">Pendaftaran</a>
                <span class="breadcrumb-item active">Pengumuman</span>
            </nav>
        </div>

        <div class="main-body border">
            <div class="row">
                <div class="col-md-2">
                    <img src="<?php echo e(Auth::guard('recruitment')->user()->student->photo ?? Auth::guard('recruitment')->user()->teacher->photo ??  Auth::guard('recruitment')->user()->staff->photo ?? ''); ?>" width="100%" alt="">
                </div>
                <div class="col-md-10">
                    <h5>Biodata</h5>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-2">No Pendaftaran</div>
                        <div class="col-md-7"><?php echo e(Auth::guard('recruitment')->user()->recruitment->no_registration ?? ''); ?></div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-2">Nama</div>
                        <div class="col-md-7"><?php echo e(Auth::guard('recruitment')->user()->student->name ?? Auth::guard('recruitment')->user()->teacher->name ??  Auth::guard('recruitment')->user()->staff->name ?? ''); ?></div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-2">Jenis Kelamin</div>
                        <div class="col-md-7" style="text-transform: capitalize;"><?php echo e(Auth::guard('recruitment')->user()->student->gender ?? Auth::guard('recruitment')->user()->teacher->gender ??  Auth::guard('recruitment')->user()->staff->gender ?? ''); ?></div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-2">Tempat & Tanggal Lahir</div>
                        <div class="col-md-7" style="text-transform: capitalize;">
                            <?php echo e(Auth::guard('recruitment')->user()->student->birthday_at ?? Auth::guard('recruitment')->user()->teacher->birthday_at ??  Auth::guard('recruitment')->user()->staff->birthday_at ?? ''); ?>, 
                            <?php echo e(Auth::guard('recruitment')->user()->student->birthday ?? Auth::guard('recruitment')->user()->teacher->birthday ??  Auth::guard('recruitment')->user()->staff->birthday ?? ''); ?>

                        </div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-2">No. Handphone</div>
                        <div class="col-md-7"><?php echo e(Auth::guard('recruitment')->user()->student->phone ?? Auth::guard('recruitment')->user()->teacher->phone ??  Auth::guard('recruitment')->user()->staff->phone ?? ''); ?></div>
                    </div>
                </div>
                <div class="mt-4">
                    <?php if(Auth::guard('recruitment')->user()->recruitment->result == 1): ?>
                        <div class="alert alert-success">
                            <strong>Selamat!</strong> anda dinyatakan lolos seleksi penerimaan <?php echo e(Auth::guard('recruitment')->user()->unit_id == 1 ? 'Guru & Karyawan' : 'Peserta Didik'); ?> Yayasan Sendikasih Sandika. Silakan lakukan pendaftaran ulang secara offline di Yayasan Sendikasih Sandika. 
                        </div>
                        <a href="<?php echo e(route('recruitment.print')); ?>" class="btn btn-primary"><i class="bi bi-printer"></i> Cetak Kartu Pendaftaran</a>
                    <?php else: ?> 
                        <div class="alert alert-danger">
                            <strong>Mohon Maaf,</strong> anda dinyatakan tidak lolos seleksi penerimaan <?php echo e(Auth::guard('recruitment')->user()->unit_id == 1 ? 'Guru & Karyawan' : 'Peserta Didik'); ?> Yayasan Sendikasih Sandika. Tetap semangat dan jangan menyerah. 
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <?php if (isset($component)) { $__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppRecruitmentFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-recruitment-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppRecruitmentFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e)): ?>
<?php $component = $__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e; ?>
<?php unset($__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/recruitment/dashboard/finish.blade.php ENDPATH**/ ?>