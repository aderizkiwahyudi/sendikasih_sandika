<div>
    <!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
</div><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/components/app-admin-aside.blade.php ENDPATH**/ ?>