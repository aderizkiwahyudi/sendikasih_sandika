<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <style>
            .breadcrumb-wrapper {
                display: none;
            }
            .content {
                margin-top: 40px;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <div id="content-wrapper bg-white">
        
        <main class="w-100">
        
            <?php if (isset($component)) { $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminNavigation::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminNavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e)): ?>
<?php $component = $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e; ?>
<?php unset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e); ?>
<?php endif; ?>
            
            <div class="content content-editor">
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="_token" id="csrf" value="<?php echo e(csrf_token()); ?>"/>
                    <div class="form-group form-header mb-4">
                        <div class="row">
                            <div class="col-md-10 mb-3">
                                <input type="text" value="<?php echo e(old('title', $gallery->title ?? '')); ?>" class="form-control" name="title" placeholder="Apa yang ingin anda tulis hari ini?"/>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary w-100">Simpan</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-8">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        Terdapat kesalahan untuk menyimpan data :
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>                                    
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <textarea name="content" id="editor"><?php echo e(old('content', $gallery->content ?? '')); ?></textarea>
                            </div>
                            <div class="col-md-4">
                                <div class="card mb-4">
                                    <div class="card-header bg-light text-dark">
                                        FOTO-FOTO
                                    </div>
                                    <div class="p-3">
                                        <input type="file" name="photo[]" class="form-control" multiple/>
                                    </div>
                                </div>
                                <?php if(isset($gallery->photos)): ?>
                                    <div class="card mb-4">
                                        <div class="card-header bg-light text-dark">
                                            DAFTAR FOTO
                                        </div>
                                        <div class="p-3">
                                            <table class="table table-stripped">
                                                <?php $__empty_1 = true; $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><img src="<?php echo e($photo->url); ?>" alt="Foto" width="50px" height="50px"></td>
                                                        <td class="width:5% text-end"><a href="<?php echo e(route('admin.gallery.item.delete', $photo->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm(`Hapus Galeri?`)"> <i class="bi bi-trash"></i></a></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    Tidak ada photo                                                  
                                                <?php endif; ?> 
                                            </table>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </main>
    </div>

    <?php $__env->startPush('script'); ?>
        <script src="<?php echo e(asset('plugin/ckeditor/build/ckeditor.js')); ?>"></script>
        <script src="<?php echo e(asset('plugin/ckeditor/build/myUploadAdapter.js')); ?>"></script>
        <script>
            ClassicEditor
            .create( document.querySelector( '#editor' ), {
                extraPlugins: [ MyCustomUploadAdapterPlugin ],
            } )
            .catch( error => {
                console.log( error );
            } );
        </script>
    <?php $__env->stopPush(); ?>    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/gallery/add.blade.php ENDPATH**/ ?>