<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Penerimaan Yayasan Sendikasih Sandika'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/recruitment-dashboard.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppRecruitmentHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-recruitment-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppRecruitmentHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb)): ?>
<?php $component = $__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb; ?>
<?php unset($__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb); ?>
<?php endif; ?>
    
    <main>
        <div class="breadcrumb-container">
            <h1>Pengaturan</h1>
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="#">Dashboard</a>
                <a class="breadcrumb-item" href="#">User</a>
                <span class="breadcrumb-item active">Pengaturan</span>
            </nav>
        </div>
        
        <div class="main-body border">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-4 alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <strong>Terdapat kesalahan, berikut :</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success mt-4 alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <form method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group mb-3">
                            <label for="" class="mb-2">Username</label>
                            <input type="text" name="username" class="form-control" value="<?php echo e(Auth::guard('recruitment')->user()->username); ?>" placeholder="Masukan username anda"/>
                        </div>
                        <div class="form-group mb-3">
                            <label for="" class="mb-2">Email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo e(Auth::guard('recruitment')->user()->email); ?>" placeholder="Masukan email anda" disabled/>
                        </div>
                        <div class="form-group mb-3">
                            <label for="" class="mb-2">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="*********"/>
                            <small class="text-danger">Kosongkan jika tidak ingin mengubah</small>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
    
    <?php if (isset($component)) { $__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppRecruitmentFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-recruitment-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppRecruitmentFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e)): ?>
<?php $component = $__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e; ?>
<?php unset($__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/recruitment/dashboard/setting.blade.php ENDPATH**/ ?>