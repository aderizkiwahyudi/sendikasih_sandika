<footer>
    <p>Yayasan Sendikasih Sandika © 2022</p>
</footer><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/recruitment/layout/footer.blade.php ENDPATH**/ ?>