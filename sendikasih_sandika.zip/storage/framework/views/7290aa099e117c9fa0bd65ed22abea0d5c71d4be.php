<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Sistem Akademik'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="css/recruitment-register-login.css">
    <?php $__env->stopPush(); ?>

    <div class="container">
        <main class="d-flex align-items-center justify-content-center">
            <div>
                <div class="main-header text-center">
                    <a href="/"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" width="135px"/></a>
                    <div class="my-5">
                        <h4>SISTEM <strong>AKADEMIK</strong></h4>
                        <p>Masuk password baru anda untuk mengubah password lama</p>
                    </div>
                </div>
                <?php if(Session::has('failed')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <?php echo e(Session::get('failed')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="main-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <div class="rounded border">
                            <div class="form-group">
                                <label for="">PASSWORD BARU</label>
                                <input type="password" name="password" placeholder="Masukan password baru anda" class="form-control-custom"/>
                            </div>
                            <div class="form-group">
                                <label for="">KONFIRMASI PASSWORD BARU</label>
                                <input type="password" name="repassword" placeholder="Masukan kembali password baru anda" class="form-control-custom"/>
                            </div>
                        </div>
                        <div class="form-group my-4">
                            <button type="submit" class="btn btn-primary w-100 py-3">SIMPAN</button>
                        </div>
                    </form>
                </div>
                <div class="main-footer">
                    <p>Yayasan Sendikasih Sandika © 2022</p>
                </div>
            </div>
        </main>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/setNewPassword.blade.php ENDPATH**/ ?>