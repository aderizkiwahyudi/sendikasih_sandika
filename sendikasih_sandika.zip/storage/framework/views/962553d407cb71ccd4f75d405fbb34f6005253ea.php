<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/admin-login.css')); ?>">
    <?php $__env->stopPush(); ?>

    <div class="main">
        <aside class="shadow">
            <div class="login-wrapper row align-items-center justify-content-center">
                <div class="col-md-12">
                    <div class="mb-4">
                        <a href="<?php echo e(route('admin.login')); ?>">
                            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" width="100px"/>
                        </a>
                    </div>
                    <h5><strong>Login</strong></h5>
                    <p>Masukan akun untuk mengakses halaman selanjutnya</p>
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label for="" class="mb-2">Username atau Email</label>
                            <input type="text" class="form-control" name="username" placeholder="Masukan username atau email"/>
                        </div>
                        <div class="form-group mb-3">
                            <label for="" class="mb-2">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Masukan password"/>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary w-100">MASUK</button>
                        </div>
                        <?php if(Session::has('failed')): ?>
                            <div class="alert alert-danger alert-dismissible fade show mt-4" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                <?php echo e(Session::get('failed')); ?>

                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </aside>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/login.blade.php ENDPATH**/ ?>