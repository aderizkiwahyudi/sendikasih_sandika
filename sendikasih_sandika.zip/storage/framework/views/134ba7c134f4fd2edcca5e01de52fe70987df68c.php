<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => ''.e(ucwords(str_replace('-', ' ', Request::segment(2)))).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    
    <section class="breadcrumb">
        <div class="container">
            <h4 class="text-white"><?php echo e($page->title ?? ucwords(str_replace('-', ' ', Request::segment(2)))); ?></h4>
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="/">Home</a>
                <a class="breadcrumb-item" href="#">Halaman</a>
                <span class="breadcrumb-item active"><?php echo e($page->title ?? ucwords(str_replace('-', ' ', Request::segment(2)))); ?></span>
            </nav>
        </div>
    </section>

    <?php if($page): ?>
        <section class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 aside">
                        <?php if (isset($component)) { $__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsidePage::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsidePage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f)): ?>
<?php $component = $__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f; ?>
<?php unset($__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-9">
                        <h2><?php echo e($page->title); ?></h2>
                        
                        <div class="article-text my-3">
                            <?php echo $page->content; ?>

                        </div>

                        <?php if(Request::segment(2) == 'struktur-pimpinan'): ?>                            
                            <?php $__empty_1 = true; $__currentLoopData = $structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <h5 class=""><?php echo e($item->name); ?></h5>
                                <div class="row justify-content-center">
                                    <?php $__currentLoopData = $item->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <div class="card">
                                                <img src="<?php echo e($list->photo); ?>" alt="Photo" width="100%"/>
                                                <div class="card-footer text-center">
                                                    <p class="m-0"><?php echo e($list->name); ?></p>
                                                    <small><?php echo e($list->description); ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Belum terdapat struktur</p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <?php $__env->startPush('styles'); ?>
            <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">   
        <?php $__env->stopPush(); ?>

        <section class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 aside">
                        <?php if (isset($component)) { $__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsidePage::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsidePage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f)): ?>
<?php $component = $__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f; ?>
<?php unset($__componentOriginal03dacdab8db5fff22a65469af26442ce84b6960f); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-9">
                        <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(2)))); ?></h2>
                        <div class="article-text my-3">
                            <table id="myTable" class="display">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Tahun</th>
                                        <th>Keterangan</th>
                                        <th>Download</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->title); ?></td>
                                            <td><?php echo e($item->year); ?></td>
                                            <td><?php echo e($item->description); ?></td>
                                            <td><a href="<?php echo e($item->url); ?>"><i class="bi bi-file-earmark-pdf"></i>Download</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <?php $__env->startPush('script'); ?>
            <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
            <script>
                $(document).ready( function () {
                    $('#myTable').DataTable();
                });
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/page.blade.php ENDPATH**/ ?>