<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div id="content-wrapper bg-white">
        
        <?php if (isset($component)) { $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminAside::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminAside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630)): ?>
<?php $component = $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630; ?>
<?php unset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630); ?>
<?php endif; ?>
        
        <main>
        
            <?php if (isset($component)) { $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminNavigation::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminNavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e)): ?>
<?php $component = $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e; ?>
<?php unset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e); ?>
<?php endif; ?>
            
            <div class="content">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        Terdapat kesalahan untuk menyimpan data :
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>                                    
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <h4>PENGATURAN PENERIMAAN</h4>
                            <div>
                               
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="post">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group mb-3 d-flex align-items-center justify-content-between">
                                        <label for="" class="mb-1"><?php echo e($item->unit_id == 1 ? 'PPDB MI' : ($item->unit_id == 2 ? 'PPDB SMP' : ($item->unit_id == 3 ? 'PPDB SMA' : 'PENERIMAAN GURU'))); ?></label>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="ppdb_<?php echo e($item->unit_id); ?>" <?php echo e($item->active == 1 ? 'checked' : ''); ?>>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">SIMPAN</button>
                                    <a href="<?php echo e(route('admin.recruitment.reset')); ?>" class="btn btn-danger" onclick="return confirm('Reset PPDB? Jika Ya, Semua data yang berkaitan dengan PPDB akan hilang.')">RESET PPDB</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/recruitment/setting.blade.php ENDPATH**/ ?>