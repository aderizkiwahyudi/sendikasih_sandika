<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div id="content-wrapper bg-white">
        
        <?php if (isset($component)) { $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminAside::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminAside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630)): ?>
<?php $component = $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630; ?>
<?php unset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630); ?>
<?php endif; ?>
        
        <main>
        
            <?php if (isset($component)) { $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminNavigation::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminNavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e)): ?>
<?php $component = $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e; ?>
<?php unset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e); ?>
<?php endif; ?>
            
            <div class="content">
                <div class="row">
                    <div class="col col-md-3 mb-3">
                        <div class="bg-white shadow-sm border rounded p-3">
                            <h3><?php echo e(count($student)); ?></h3>
                            <small>SISWA AKTIF</small>
                        </div>
                    </div>
                    <div class="col col-md-3 mb-3">
                        <div class="bg-white shadow-sm border rounded p-3">
                            <h3><?php echo e(count($teacher) + count($staff)); ?></h3>
                            <small>GURU & STAFF</small>
                        </div>
                    </div>
                    <div class="col col-md-3 mb-3">
                        <div class="bg-white shadow-sm border rounded p-3">
                            <h3><?php echo e(count($ppdb)); ?></h3>
                            <small>PENDAFTAR PPDB</small>
                        </div>
                    </div>
                    <div class="col col-md-3 mb-3">
                        <div class="bg-white shadow-sm border rounded p-3">
                            <h3><?php echo e(count($penerimaan_guru_staff)); ?></h3>
                            <small>PENDAFTAR GURU & STAFF</small>
                        </div>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <h4>DATA SISWA</h4>
                        </div>
                        <div class="card-body">
                            <div id="piechart" style="width: 100%; height: 450px;"></div>
                        </div>
                    </div>
                    <div class="col col-md-3 mb-3">
                        <div class="bg-white shadow-sm border rounded p-3">
                            <h3><?php echo e($year->name); ?></h3>
                            <small>TAHUN AKADEMIK</small>
                        </div>
                    </div>
                    <div class="col col-md-3 mb-3">
                        <div class="bg-white shadow-sm border rounded p-3">
                            <h3><?php echo e(strtoupper($year->status)); ?></h3>
                            <small>SEMESTER</small>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <?php $__env->startPush('script'); ?>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            let siswaMI = <?php echo e(count($student->filter(function($item){ return $item->account->unit_id == 2; }))); ?>

            let siswaSMP = <?php echo e(count($student->filter(function($item){ return $item->account->unit_id == 3; }))); ?>

            let siswaSMA = <?php echo e(count($student->filter(function($item){ return $item->account->unit_id == 4; }))); ?>


            var data = google.visualization.arrayToDataTable([
            ['Unit', 'Jumlah Siswa'],
            ['MI', siswaMI],
            ['SMP', siswaSMP],
            ['SMA', siswaSMA],
            ]);

            var options = {
            title: 'Jumlah Data Siswa'
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));

            chart.draw(data, options);
        }
        </script>
    <?php $__env->stopPush(); ?>    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>