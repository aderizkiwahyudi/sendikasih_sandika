<div class="background-navigation"></div>
<header>
    <div class="header container">
        <div class="d-flex align-items-center justify-content-between">
            <div class="logo">
                <a href="/">
                    <img src="<?php echo e(asset('img/logo-white.png')); ?>" alt="Logo" width="110px"/>
                </a>
            </div>
            <a href="javascript:void(0)" class="bars text-white"><i class="bi bi-list"></i></a>
            <div class="navigation">
                <nav>
                    <ul>
                        <li class="active">
                            <a href="/"><i class="bi bi-house-door-fill"></i></a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">PROFILE</a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('/halaman/tepak-sirih')); ?>">Tepak Sirih</a></li>
                                <li><a href="<?php echo e(url('/halaman/sejarah')); ?>">Sejarah</a></li>
                                <li><a href="<?php echo e(url('/halaman/visi-misi')); ?>">Visi & Misi</a></li>
                                <li><a href="<?php echo e(url('/halaman/lambang')); ?>">Lambang</a></li>
                                <li><a href="<?php echo e(url('/halaman/struktur-pimpinan')); ?>">Struktur Pimpinan</a></li>
                                <li><a href="<?php echo e(url('/halaman/lokasi-kantor-pusat')); ?>">Lokasi Kantor Pusat</a></li>
                                <li><a href="<?php echo e(url('/halaman/rencana-strategis')); ?>">Rencana Strategis</a></li>
                                <li><a href="<?php echo e(url('/halaman/perjanjian-kerja')); ?>">Perjanjian Kerja</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0)">UNIT TUGAS</a>
                            <ul class="submenu">
                                <li><a href="#">Tata Usaha</a></li>
                                <li><a href="#">MI Sendikasih Sandika</a></li>
                                <li><a href="#">MTS Sendikasih Sandika</a></li>
                                <li><a href="#">SMA Sendikasih Sandika</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0)">PRESTASI</a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('kategori/akademik')); ?>">Akademik</a></li>
                                <li><a href="<?php echo e(url('kategori/nonakademik')); ?>">Non Akademik</a></li>
                                <li><a href="<?php echo e(url('kategori/publikasi-karya')); ?>">Publikasi Karya</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">PENGUMUMAN</a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('kategori/beasiswa')); ?>">Beasiswa</a></li>
                                <li><a href="<?php echo e(url('berita')); ?>">Berita</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">PENERIMAAN</a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(url('pendaftaran/peserta-didik')); ?>">MI/SMP/SMA</a></li>
                                <li><a href="<?php echo e(url('pendaftaran/guru-karyawan')); ?>">Guru & Karyawan</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo e(url('galeri')); ?>">GALERI</a>
                        </li>
                        <li class="mobile-display">
                            <a href="<?php echo e(url('masuk')); ?>">MASUK</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header-login">
                <a href="<?php echo e(url('masuk')); ?>" class="btn btn-login">MASUK</a>
            </div>
        </div>
    </div>
</header>

<?php $__env->startPush('script'); ?>
<script>
    $('.bars').on('click', () => {
        $('.background-navigation').show();
        $('.header').find('.navigation').show();
    })
    
    $('.background-navigation').on('click', () => {
        $('.header').find('.navigation').addClass('navigation-out');
        setTimeout(() => {
            $('.header').find('.navigation').removeClass('navigation-out');
            $('.header').find('.navigation').hide();
            $('.background-navigation').hide();
        }, 350);
    })

    headerFixed($(window).scrollTop());

    $(window).scroll(function(){
        let scroll = $(this).scrollTop();
        headerFixed(scroll);
    });

    function headerFixed(scroll){
        if(scroll > 100){
            $('header').addClass('header-fixed header-fixed-remove');
        }else if(scroll < 100){
            $('header').removeClass('header-fixed');
        }
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/layouts/header.blade.php ENDPATH**/ ?>