<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/academic-dashboard.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeaderAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeaderAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718)): ?>
<?php $component = $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718; ?>
<?php unset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718); ?>
<?php endif; ?>

    <main>
        <div class="container">
            <div class="row">

                <?php if (isset($component)) { $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsideAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsideAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2)): ?>
<?php $component = $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2; ?>
<?php unset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2); ?>
<?php endif; ?>
                
                <div class="col-md-8">
                    <div>
                        <h5 class="mb-1">Keuangan Pribadi</h5>
                        <nav class="breadcrumb">
                            <a class="breadcrumb-item" href="#">Home</a>
                            <span class="breadcrumb-item active">Keuangan Pribadi</span>
                        </nav>
                    </div>
                    <div class="content-body">
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <form method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row align-items-center">
                                        <div class="col-md-2">
                                            <strong>Tahun :</strong>
                                        </div>
                                        <div class="col-md-4">
                                            <select name="tahun" class="form-control">
                                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->name); ?>" <?php echo e($item->id == $yearNow ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <select name="status" class="form-control">
                                                <option value="ganjil" <?php echo e(strtolower($semester) == 'ganjil' ? 'selected' : ''); ?>>Semester Ganjil</option>
                                                <option value="genap" <?php echo e(strtolower($semester) == 'genap' ? 'selected' : ''); ?>>Semester Genap</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <button type="submit" class="btn btn-primary w-100">Cek</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-12">
                                <?php $__currentLoopData = $contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="box shadow-sm mb-4 border">
                                        <h5 class="mb-0"><?php echo e($contribution->name); ?></h5>
                                        <small><?php echo e($contribution->description); ?></small>
                                        <table class="table table-stripped">
                                            <thead>
                                                <tr>
                                                    <td>#</td>
                                                    <td>Nama</td>
                                                    <td class="text-center">Keterangan</td>
                                                    <td class="text-center">Nominal</td>
                                                    <td class="text-center">Dibayar</td>
                                                    <td class="text-center">Status</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $year_id = $yearNow;
                                                    $contributionOnYear = $contribution->item->filter(function($val, $key) use ($year_id){
                                                        return $val['year_id'] == $year_id;
                                                    });

                                                    #Pembayaran PPDB Hanya muncul satu kali ditahun pertama
                                                    if($key == 0){
                                                        $contributionOnYear = $contribution->item->filter(function($val){
                                                            return $val['year_id'] == Auth::guard('academic')->user()->student->year_id;
                                                        });
                                                    }

                                                    $lunas = 0;
                                                ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $contributionOnYear->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        $sum = 0;
                                                        foreach ($item->payment as $key => $payment) {
                                                            $sum += $payment->nominal;
                                                        }

                                                        if($item->nominal == $sum) $lunas +=1;
                                                    ?>
                                                    <tr class="vertical-align:middle;">
                                                        <td><?php echo e($i + 1); ?></td>
                                                        <td><?php echo e($item->name); ?></td>
                                                        <td><?php echo e($item->description); ?></td>
                                                        <td class="text-center">Rp<?php echo e(number_format($item->nominal,0,'.','.')); ?></td>
                                                        <td>Rp<?php echo e(number_format($sum,0,'.','.')); ?></td>
                                                        <td class="text-center">
                                                                <?php echo $item->nominal >= $sum ? '<small class="text-success">Lunas</small>' : '<small class="text-danger">Belum Lunas</small>'; ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="6" class="text-center">Belum ada data</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="4">Status Keseluruhan</td>
                                                    <td colspan="2" class="text-end">
                                                        <?php echo count($contributionOnYear) == 0 ? '-' : (count($contributionOnYear) == $lunas ? '<small class="text-success">Lunas</small>' : '<small class="text-danger">Belum Lunas</small>'); ?>

                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/academic/finance.blade.php ENDPATH**/ ?>