<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('styles'); ?>
        <style>
            .container-card {
                width: 500px;
                background: #fff;
                border: 2px dashed rgba(0,0,0,0.5);
                padding: 10px;
            }
            .card-header {
                display: flex;
                align-items: center;
                border: 1px solid rgba(0,0,0,0.2);
                padding: 20px;
            }

            .card-header h5 {
                font-size: 14px;
                font-weight: bold;
            }

            .card-header p {
                font-size: 12px;
                margin: 0;
            }

            .card-body {
                padding: 20px;
                border: 1px solid rgba(0,0,0,0.2);
                font-size: 12px;
            }
            .card-footer {
                border: 1px solid rgba(0,0,0,0.2);
                font-size: 12px;
                text-align: center;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <div class="container-card">
        <div class="card-header">
            <div class="me-4">
               <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" width="100px"/>
            </div>
            <div>
                <h5>Yayasan Sendikasih Sandika</h5>
                <p>Jl. Palembang - Betung No.KM.14.5, Sukajadi, Kec. Talang Klp., Kab. Banyuasin, Sumatera Selatan 30953</p>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <img src="<?php echo e(Auth::guard('recruitment')->user()->student->photo ?? Auth::guard('recruitment')->user()->teacher->photo ??  Auth::guard('recruitment')->user()->staff->photo ?? ''); ?>" width="100%" alt="">
                </div>
                <div class="col-md-9">
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-4">No. Pendaftaran</div>
                        <div class="col-md-8">: <?php echo e(Auth::guard('recruitment')->user()->recruitment->no_registration ?? ''); ?></div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-4">Nama</div>
                        <div class="col-md-8">: <?php echo e(Auth::guard('recruitment')->user()->student->name ?? Auth::guard('recruitment')->user()->teacher->name ??  Auth::guard('recruitment')->user()->staff->name ?? ''); ?></div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-4">Jenis Kelamin</div>
                        <div class="col-md-8" style="text-transform: capitalize;">: <?php echo e(Auth::guard('recruitment')->user()->student->gender ?? Auth::guard('recruitment')->user()->teacher->gender ??  Auth::guard('recruitment')->user()->staff->gender ?? ''); ?></div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-4">TTL</div>
                        <div class="col-md-8" style="text-transform: capitalize;">: 
                            <?php echo e(Auth::guard('recruitment')->user()->student->birthday_at ?? Auth::guard('recruitment')->user()->teacher->birthday_at ??  Auth::guard('recruitment')->user()->staff->birthday_at ?? ''); ?>, 
                            <?php echo e(Auth::guard('recruitment')->user()->student->birthday ?? Auth::guard('recruitment')->user()->teacher->birthday ??  Auth::guard('recruitment')->user()->staff->birthday ?? ''); ?>

                        </div>
                    </div>
                    <div class="form-grup row align-items-center mb-2">
                        <div class="col-md-4">No. Handphone</div>
                        <div class="col-md-8">: <?php echo e(Auth::guard('recruitment')->user()->student->phone ?? Auth::guard('recruitment')->user()->teacher->phone ??  Auth::guard('recruitment')->user()->staff->phone ?? ''); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            Peserta dinyatakan lolos seleksi penerimaan <?php echo e(Auth::guard('recruitment')->user()->unit_id == 1 ? 'Guru & Karyawan' : 'Peserta Didik'); ?> Yayasan Sendikasih Sandika.
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            window.print();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/recruitment/dashboard/print.blade.php ENDPATH**/ ?>