<header class="shadow-sm">
    <div class="container">
        <div class="header">
            <div class="logo d-flex align-items-center">
                <a href="<?php echo e(url('akademik')); ?>">
                    <img src="<?php echo e(asset('img/icon.png')); ?>" width="40px" alt="Logo"/>
                </a>
                <a href="<?php echo e(url('akademik')); ?>">
                    <h5 class="text-white mb-0 ms-3">SISTEM AKADEMIK</h5>
                </a>
            </div>
            <div class="nav">
                <a class="nav-link dropdown-toggle p-0" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-person-circle"></i>
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="<?php echo e(route('academic.dashboard')); ?>">Halaman Utama</a></li>
                    <?php if(Auth::guard('academic')->user()->student): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('academic.finance')); ?>">Pembayaran Saya</a></li>
                    <?php endif; ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('academic.setting')); ?>">Pengaturan</a></li>
                    <li class="border-top"><a class="dropdown-item text-danger" href="<?php echo e(route('academic.logout')); ?>">Keluar</a></li>
                </ul>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/academic/layout/header.blade.php ENDPATH**/ ?>