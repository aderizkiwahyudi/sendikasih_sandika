<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/academic-dashboard.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeaderAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeaderAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718)): ?>
<?php $component = $__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718; ?>
<?php unset($__componentOriginal575bf535bcb452b279c101de2fe6672a974fe718); ?>
<?php endif; ?>

    <main>
        <div class="container">
            <div class="row">

                <?php if (isset($component)) { $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAsideAcademic::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-aside-academic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAsideAcademic::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2)): ?>
<?php $component = $__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2; ?>
<?php unset($__componentOriginal28d8b0b163bfdb2fe57b9cf69a19c69ef5ac47d2); ?>
<?php endif; ?>
                
                <div class="col-md-8">
                    <div>
                        <h5 class="mb-1">Dashboard</h5>
                        <nav class="breadcrumb">
                            <a class="breadcrumb-item" href="#">Home</a>
                            <span class="breadcrumb-item active">Dashboard</span>
                        </nav>
                    </div>
                    <div class="content-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="box shadow-sm border mb-4">
                                    <div class="d-flex align-items-center">
                                        <div class="me-4">
                                            <div class="icon-active text-success">
                                                <i class="bi bi-check-circle-fill"></i>
                                            </div>
                                        </div>
                                        <div>
                                            <h5 class="headline">STATUS</h5>
                                            <p class="mb-0">AKTIF</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="box shadow-sm border">
                                    <table border="0">
                                        <tr>
                                            <td>Nama</td>
                                            <td class="px-2">:</td>
                                            <td><?php echo e(Auth::guard('academic')->user()->student->name ?? Auth::guard('academic')->user()->teacher->name ?? Auth::guard('academic')->user()->staff->name ?? ''); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Unit</td>
                                            <td class="px-2">:</td>
                                            <td><?php echo e(Auth::guard('academic')->user()->unit->name); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Status</td>
                                            <td class="px-2">:</td>
                                            <td>
                                                <?php echo e(Auth::guard('academic')->user()->student ? 'Siswa' : (Auth::guard('academic')->user()->teacher ? 'Guru' : 'Staff')); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="box shadow-sm border mb-4">
                                    <div class="align-items-center">
                                        <div>
                                            <h5 class="headline">Tahun Ajaran</h5>
                                            <p class="mb-0"><?php echo e($setting->year->name); ?> - Semester <?php echo e($setting->year->status); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php if(Auth::guard('academic')->user()->student): ?>
                                    <div class="box shadow-sm border">
                                        <div>
                                            <h5 class="mb-0">Keungan Pribadi</h5>
                                            <small>Keuangan yang belum dibayar</small>
                                        </div>
                                        
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/academic/index.blade.php ENDPATH**/ ?>