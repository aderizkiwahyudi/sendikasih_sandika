<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Penerimaan Yayasan Sendikasih Sandika'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/recruitment-dashboard.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppRecruitmentHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-recruitment-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppRecruitmentHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb)): ?>
<?php $component = $__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb; ?>
<?php unset($__componentOriginal39477b145ebf806354fbd06b95d20dd435e35fdb); ?>
<?php endif; ?>
    
    <main>
        <div class="breadcrumb-container">
            <h1>Pendaftaran</h1>
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="#">Dashboard</a>
                <a class="breadcrumb-item" href="#">Pendaftaran</a>
                <span class="breadcrumb-item active">Pengisian Biodata</span>
            </nav>
        </div>

        <div class="main-body border">
            <div class="step-container">
                <ul class="step">
                    <li class="finish">
                        <div class="step-number">✓</div>
                        <div class="step-content">
                            <h4>Pengisian Biodata</h4>
                            <small>Isi Biodata Diri Anda</small>
                        </div>
                        <div class="step-border"></div>
                    </li>
                    <li class="active">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h4>Unggah Foto</h4>
                            <small>Unggah Foto Anda</small>
                        </div>
                        <div class="step-border"></div>
                    </li>
                    <li>
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h4>Konfirmasi Data</h4>
                            <small>Konfirmasi Data</small>
                        </div>
                        <div class="step-border"></div>
                    </li>
                    <li>
                        <div class="step-number">4</div>
                        <div class="step-content">
                            <h4>Selesai</h4>
                            <small>Pendaftaran Selesai</small>
                        </div>
                    </li>
                </ul>
            </div>
            <div>
                <form method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="main-form">
                        <div class="alert alert-warning">
                            <strong>Perhatian!</strong> Disarankan menggunakan ukuran foto 3x4
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger mt-4 alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                <strong>Terdapat kesalahan, berikut :</strong>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success mt-4 alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-group form-group-input">
                            <span><i class="bi bi-upload"></i></span>
                            <input type="file" name="photo" id="photo" class="file-upload"/>
                        </div>
                        <div class="preview-image">
                            <img src="<?php echo e(Auth::guard('recruitment')->user()->student->photo ?? Auth::guard('recruitment')->user()->teacher->photo ?? Auth::guard('recruitment')->user()->staff->photo ?? ''); ?>" width="100%"/>
                        </div>
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('recruitment.dashboard')); ?>" class="btn btn-danger">Kembali</a>
                        <?php if(Auth::guard('recruitment')->user()->recruitment->step > 2): ?>
                            <a href="<?php echo e(route('recruitment.confirmation')); ?>" class="btn btn-success">Selanjutnya</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

        </div>
    </main>
    
    <?php $__env->startPush('script'); ?>
        <script>
            $('#photo').on('change', function() {
                const src = URL.createObjectURL(this.files[0]);
                $('.preview-image').html(`<img src='${src}' width='100%'/>`);
            });
        </script>
    <?php $__env->stopPush(); ?>

    <?php if (isset($component)) { $__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppRecruitmentFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-recruitment-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppRecruitmentFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e)): ?>
<?php $component = $__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e; ?>
<?php unset($__componentOriginalcf44be989d726f82c576c409c911a49189b0ff8e); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/recruitment/dashboard/photo.blade.php ENDPATH**/ ?>