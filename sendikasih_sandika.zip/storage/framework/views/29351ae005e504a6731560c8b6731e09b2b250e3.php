<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
    <?php $__env->stopPush(); ?>

    <div id="content-wrapper bg-white">
        
        <?php if (isset($component)) { $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminAside::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminAside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630)): ?>
<?php $component = $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630; ?>
<?php unset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630); ?>
<?php endif; ?>
        
        <main>
        
            <?php if (isset($component)) { $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminNavigation::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminNavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e)): ?>
<?php $component = $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e; ?>
<?php unset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e); ?>
<?php endif; ?>
            
            <div class="content">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h4>BERITA</h4>
                    <div>
                        <a href="<?php echo e(route('admin.news.add')); ?>" class="btn btn-success">+ Tambah</a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped" id="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <?php $__env->startPush('script'); ?>
        <script src="https://cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
        <script>
            $(function() {
                $('#table').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.news.data'); ?>',
                    columns: [
                        { data: 'DT_RowIndex', name: 'id' },
                        { data: 'title', name: 'title' },
                        { data: 'category', name: 'category' },
                        { data: 'action', name: 'action', orderable: false, searchable: false }
                    ],
                    columnDefs: [
                        {
                            "targets": 0,
                            "className": "text-center",
                            "width": "5%",
                        },
                        {
                            "targets": 3,
                            "className": "text-center",
                            "width": "20%",
                        }
                    ],
                });
            });
        </script>
    <?php $__env->stopPush(); ?>    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/news/index.blade.php ENDPATH**/ ?>