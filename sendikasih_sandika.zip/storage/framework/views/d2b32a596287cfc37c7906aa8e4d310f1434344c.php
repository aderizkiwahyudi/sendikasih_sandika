<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
        <style>
            table, tr, td {
                vertical-align: top;
            }
        </style>
        <style type="text/css" media="print">
            @page  
            {
                size: auto;   /* auto is the initial value */
                margin: 0mm;  /* this affects the margin in the printer settings */
            }
        </style>
    <?php $__env->stopPush(); ?>

    <div id="content-wrapper bg-white">
        
        
        <main>
        
            <div class="content p-5">
                <div>
                    <table>
                        <tr>
                            <td class="pe-5">
                                <div class="max-height-200">
                                    <img src="<?php echo e($user->photo ?? ""); ?>" alt="Photo" width="100px"/>
                                </div>
                            </td>
                            <td>
                                <div class="row">
                                    <div class="col-md-9">
                                        <h5><?php echo e(strtoupper($user->name ?? '')); ?></h5>
                                        <p><?php echo e($user->account->student ? 'NISN.' : 'NIP.'); ?> <?php echo e($user->nisn ?? $user->nip ??  ''); ?> · <?php echo e($user->account->email); ?> · <span class="statusID"><?php echo e(strtoupper(get_status($user->status_id ?? '1'))); ?></span></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <small class="bio-label">Tempat, Tanggal Lahir</small>
                                        <p><?php echo e($user->birthday_at ?? ''); ?>, <?php echo e(date('d/m/Y', strtotime($user->birthday ?? ""))); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="bio-label">JENIS KELAMIN</small>
                                        <p><?php echo e(ucwords($user->gender ?? '')); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="bio-label">UNIT</small>
                                        <p><?php echo e($user->account->unit_id == 1 ? 'Belum Memiliki Unit' : unit_name($user->account->unit_id)); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="bio-label">STATUS AKUN</small>
                                        <p><?php echo e(strtoupper(get_status($user->status_id ?? '1'))); ?></p>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="alert" class="mt-3"></div>
                <div class="menus-detail-user mt-3">
                    <div class="my-0">
                        <div class="my-3">
                            <div class="mb-3">
                                <h5 class="mb-1">Keuangan Pribadi</h5>
                                <small>Tahun akademik : <?php echo e($yearNow); ?> Semester <?php echo e($semester); ?></small>
                            </div>
                            <div class="content-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php $__currentLoopData = $contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="box mb-4 border p-3">
                                                <h5 class="mb-0"><?php echo e($contribution->name); ?></h5>
                                                <small><?php echo e($contribution->description); ?></small>
                                                <table class="table table-stripped">
                                                    <thead>
                                                        <tr>
                                                            <td>#</td>
                                                            <td>Nama</td>
                                                            <td class="text-center">Keterangan</td>
                                                            <td class="text-center">Nominal</td>
                                                            <td class="text-center">Dibayar</td>
                                                            <td class="text-center">Status</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $contributionOnYear = $contribution->item->filter(function($val, $key) use ($year_id){
                                                                return $val['year_id'] == $year_id;
                                                            });
        
                                                            #Pembayaran PPDB Hanya muncul satu kali ditahun pertama
                                                            if($key == 0){
                                                                $contributionOnYear = $contribution->item->filter(function($val) use ($user){
                                                                    return $val['year_id'] == $user->year_id ?? 1;
                                                                });
                                                            }
        
                                                            $lunas = 0;
                                                        ?>
                                                        <?php $__empty_1 = true; $__currentLoopData = $contributionOnYear->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <?php
                                                                $sum = 0;
                                                                foreach ($item->payment as $key => $payment) {
                                                                    $sum += $payment->nominal;
                                                                }
        
                                                                if($item->nominal == $sum) $lunas +=1;
                                                            ?>  
                                                            <tr class="vertical-align:middle;">
                                                                <td><?php echo e($i + 1); ?></td>
                                                                <td><?php echo e($item->name); ?></td>
                                                                <td><?php echo e($item->description); ?></td>
                                                                <td class="text-center">Rp<?php echo e(number_format($item->nominal,0,'.','.')); ?></td>
                                                                <td>Rp<?php echo e(number_format($sum,0,'.','.')); ?></td>
                                                                <td class="text-center">
                                                                        <?php echo $item->nominal == $sum ? '<small class="text-success">Lunas</small>' : '<small class="text-danger">Belum Lunas</small>'; ?>

                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="6" class="text-center">Belum ada data</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4">Status Keseluruhan</td>
                                                            <td colspan="2" class="text-end">
                                                                <?php echo count($contributionOnYear) == 0 ? '-' : (count($contributionOnYear) == $lunas ? '<small class="text-success">Lunas</small>' : '<small class="text-danger">Belum Lunas</small>'); ?>

                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $__env->startPush('script'); ?>
                <script>
                    window.print();
                </script>
            <?php $__env->stopPush(); ?>
        </main>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/academic/print.blade.php ENDPATH**/ ?>