<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
    <?php $__env->stopPush(); ?>

    <div id="content-wrapper bg-white">
        
        <?php if (isset($component)) { $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminAside::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminAside::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630)): ?>
<?php $component = $__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630; ?>
<?php unset($__componentOriginalca772a3e9a70dc52823f078210badb4c28e8c630); ?>
<?php endif; ?>
        
        <main>
        
            <?php if (isset($component)) { $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminNavigation::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminNavigation::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e)): ?>
<?php $component = $__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e; ?>
<?php unset($__componentOriginalda4cf82d948b7fb4c6c6c10131fb46b67696e37e); ?>
<?php endif; ?>
            
            <div class="content">
                <div class="p-4 shadow-sm border rounded">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="max-height-200 photo-user">
                                <img src="<?php echo e($user->photo ?? ""); ?>" alt="Photo" width="100%"/>
                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="row">
                                <div class="col-md-9">
                                    <h5><?php echo e(strtoupper($user->name ?? '')); ?></h5>
                                    <p><?php echo e($user->account->student ? 'NISN.' : 'NIP.'); ?> <?php echo e($user->nisn ?? $user->nip ??  ''); ?> · <?php echo e($user->account->email); ?> · <span class="statusID"><?php echo e(strtoupper(get_status($user->status_id ?? '1'))); ?></span></p>
                                </div>
                                <div class="col-md-3">
                                    <div class="d-flex justify-content-end button-edit-delete">
                                        <a href="<?php echo e(route('admin.users.academic.edit', [Request::segment(3), Request::segment(4), $user->account->unit_id])); ?>" class="btn btn-primary me-2"><i class="bi bi-pencil-square"></i></a>
                                        <a href="<?php echo e(route('admin.users.academic.delete', [Request::segment(3), Request::segment(4)])); ?>" class="btn btn-danger" onclick="return confirm(`Hapus Siswa?`)"><i class="bi bi-trash"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <small class="bio-label">Tempat, Tanggal Lahir</small>
                                    <p><?php echo e($user->birthday_at ?? ''); ?>, <?php echo e(date('d/m/Y', strtotime($user->birthday ?? ""))); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <small class="bio-label">JENIS KELAMIN</small>
                                    <p><?php echo e(ucwords($user->gender ?? '')); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <small class="bio-label">UNIT</small>
                                    <p><?php echo e($user->account->unit_id == 1 ? 'Belum Memiliki Unit' : unit_name($user->account->unit_id)); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <small class="bio-label">STATUS AKUN</small>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" role="switch" id="switchUserStatus" <?php echo e(get_status($user->status_id ?? '1') == 'aktif' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="switchUserStatus"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="alert" class="mt-3"></div>
                <div class="menus-detail-user mt-3">
                    <ul class="nav nav-tabs">
                        <li class="nav-item active">
                            <a class="nav-link <?php echo e(Request::segment(5) == 'biodata' ? 'active' : ''); ?>" href="biodata" >BIODATA</a>
                        </li>
                        <?php if(Request::segment(3) == 'siswa'): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(Request::segment(5) == 'detail' ? 'active' : ''); ?>" href="detail">KEUANGAN</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <div class="my-0">
                        <?php if(Request::segment(5) == 'biodata'): ?>
                            <div class="p-4 border" style="border-top: 0px !important;">
                                <?php if(Request::segment(3) == 'guru'): ?>
                                    <?php echo $__env->make('admin.dashboard.academic.biodata.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php elseif(Request::segment(3) == 'staff'): ?>
                                    <?php echo $__env->make('admin.dashboard.academic.biodata.staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <?php echo $__env->make('admin.dashboard.academic.biodata.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>

                                <?php $__env->startPush('styles'); ?>
                                    <style>
                                        .main-form button, .main-form input[type='file'], .main-form small.text-danger, .main-form .form-group:nth-child(4), .main-form .form-group:nth-child(15) {
                                            display: none;
                                        }
                                        .main-form {
                                            text-transform: uppercase;
                                        }
                                        .main-form .username {
                                            text-transform: lowercase;
                                        }
                                    </style>
                                <?php $__env->stopPush(); ?>
                                <?php $__env->startPush('script'); ?>
                                    <script>
                                        const elInput = $('.main-form').find('input');
                                        for(e of elInput){
                                            $(e).replaceWith(`<div>${$(e).val()}</div>`);
                                        }

                                        const elSelect = $('.main-form').find('select');
                                        for(e of elSelect){
                                            $(e).replaceWith(`<div>${$(e).val()}</div>`);
                                        }

                                        const elTextArea = $('.main-form').find('textarea');
                                        for(e of elTextArea){
                                            $(e).replaceWith(`<div>${$(e).val()}</div>`);
                                        }
                                    </script>
                                <?php $__env->stopPush(); ?>
                            </div>
                        <?php elseif(Request::segment(3) == 'siswa'): ?>
                            <div class="my-3">
                                <div>
                                    <h5 class="mb-1">Keuangan Pribadi</h5>
                                </div>
                                <div class="content-body">
                                    <div class="row">
                                        <div class="col-md-12 mb-4">
                                            <form method="get">
                                                <div class="row align-items-center">
                                                    <div class="col-md-2 mb-2">
                                                        <strong>Tahun :</strong>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <select name="tahun" class="form-control">
                                                            <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->name); ?>" <?php echo e($item->name == $yearNow ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <select name="status" class="form-control">
                                                            <option value="ganjil" <?php echo e(strtolower($semester) == 'ganjil' ? 'selected' : ''); ?>>Semester Ganjil</option>
                                                            <option value="genap" <?php echo e(strtolower($semester) == 'genap' ? 'selected' : ''); ?>>Semester Genap</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-2 mb-2">
                                                        <div class="d-flex justify-content-between">
                                                            <button type="submit" class="btn btn-primary w-100 me-1">Cek</button>
                                                            <a href="print?tahun=<?php echo e($yearNow); ?>&status=<?php echo e(strtolower($semester)); ?>" class="btn btn-success w-100"><i class="bi bi-printer"></i> Print</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="col-md-12">
                                            <?php $__currentLoopData = $contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="box shadow-sm mb-4 border p-3">
                                                    <h5 class="mb-0"><?php echo e($contribution->name); ?></h5>
                                                    <small><?php echo e($contribution->description); ?></small>
                                                    <table class="table table-stripped">
                                                        <thead>
                                                            <tr>
                                                                <td>#</td>
                                                                <td>Nama</td>
                                                                <td class="text-center">Keterangan</td>
                                                                <td class="text-center">Nominal</td>
                                                                <td class="text-center">Dibayar</td>
                                                                <td class="text-center">Status</td>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                                $contributionOnYear = $contribution->item->filter(function($val, $key) use ($year_id){
                                                                    return $val['year_id'] == $year_id;
                                                                });
            
                                                                #Pembayaran PPDB Hanya muncul satu kali ditahun pertama
                                                                if($key == 0){
                                                                    $contributionOnYear = $contribution->item->filter(function($val) use ($user){
                                                                        return $val['year_id'] == $user->year_id ?? 1;
                                                                    });
                                                                }
            
                                                                $lunas = 0;
                                                            ?>
                                                            <?php $__empty_1 = true; $__currentLoopData = $contributionOnYear->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <?php
                                                                    $sum = 0;
                                                                    foreach ($item->payment as $key => $payment) {
                                                                        $sum += $payment->nominal;
                                                                    }
            
                                                                    if($item->nominal == $sum) $lunas +=1;
                                                                ?>  
                                                                <tr class="vertical-align:middle;">
                                                                    <td><?php echo e($i + 1); ?></td>
                                                                    <td><?php echo e($item->name); ?></td>
                                                                    <td><?php echo e($item->description); ?></td>
                                                                    <td class="text-center">Rp<?php echo e(number_format($item->nominal,0,'.','.')); ?></td>
                                                                    <td>Rp<?php echo e(number_format($sum,0,'.','.')); ?></td>
                                                                    <td class="text-center">
                                                                            <?php echo $item->nominal == $sum ? '<small class="text-success">Lunas</small>' : '<small class="text-danger">Belum Lunas</small>'; ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <tr>
                                                                    <td colspan="6" class="text-center">Belum ada data</td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <td colspan="4">Status Keseluruhan</td>
                                                                <td colspan="2" class="text-end">
                                                                    <?php echo count($contributionOnYear) == 0 ? '-' : (count($contributionOnYear) == $lunas ? '<small class="text-success">Lunas</small>' : '<small class="text-danger">Belum Lunas</small>'); ?>

                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <?php $__env->startPush('script'); ?>
        <script>
            $('#switchUserStatus').on('change', function(){
                const btn = $(this);
                let statusID = $('.statusID').html();

                btn.attr('disabled', true);
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('admin.users.academic.change.status', Request::segment(4))); ?>",
                    success: function (response) {
                        btn.removeAttr('disabled');
                        if(response.success){
                            return $('#alert').html(`
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                Berhasil mengubah status akun
                            </div>
                            `);
                            if(statusID == 'NONAKTIF'){ $('.statusID').html('AKTIF'); } else { $('.statusID').html('NONAKTIF'); }
                        }else{
                            return $('#alert').html(`
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                Gagal mengubah status akun
                            </div>
                            `);
                        }
                    }
                });
            })
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/admin/dashboard/academic/detail.blade.php ENDPATH**/ ?>