<ul>
    <li class="<?php echo e(Request::segment(1) == 'berita' ? 'active' : ''); ?>"><a href="<?php echo e(url('berita')); ?>">Berita</a></li>
    <li class="<?php echo e(Request::segment(1) == 'kategori' && Request::segment(2) == 'beasiswa' ? 'active' : ''); ?>"><a href="<?php echo e(url('kategori/beasiswa')); ?>">Beasiswa</a></li>
    <li class="<?php echo e(Request::segment(1) == 'galeri' ? 'active' : ''); ?>"><a href="<?php echo e(url('galeri')); ?>">Galeri</a></li>
    <li class="<?php echo e(Request::segment(1) == 'kategori'  && Request::segment(2) == 'akademik' ? 'active' : ''); ?>"><a href="<?php echo e(url('kategori/akademik')); ?>">Akademik</a></li>
    <li class="<?php echo e(Request::segment(1) == 'kategori'  && Request::segment(2) == 'nonakademik' ? 'active' : ''); ?>"><a href="<?php echo e(url('kategori/nonakademik')); ?>">Non Akademik</a></li>
    <li class="<?php echo e(Request::segment(1) == 'kategori'  && Request::segment(2) == 'publikasi-karya' ? 'active' : ''); ?>"><a href="<?php echo e(url('kategori/publikasi-karya')); ?>">Publikasi Karya</a></li>
</ul><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/layouts/asideNews.blade.php ENDPATH**/ ?>