<?php if($errors->any()): ?>
    <div class="alert alert-danger mt-4 alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <strong>Terdapat kesalahan, berikut :</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success mt-4 alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>
<form method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="main-form">
        <h4>BIODATA DIRI</h4>
        <div class="form-group row align-items-center mb-4">
            <div class="col-md-2">Nama <small class="text-danger">*</small></div>
            <div class="col-md-4"><input type="text" name="name" value="<?php echo e(old('name', Auth::guard('recruitment')->user()->teacher->name)); ?>" id="name" placeholder="Masukan nama anda" class="form-control"></div>
        </div>
        
        <div class="form-group row align-items-center mb-4">
            <div class="col-md-2">NIP <small class="text-danger"></small></div>
            <div class="col-md-4"><input type="number" name="nip" value="<?php echo e(old('nisn', Auth::guard('recruitment')->user()->teacher->nisn)); ?>" id="nisn" placeholder="Masukan nisn anda" class="form-control"></div>
        </div>
        
        <div class="form-group row align-items-center mb-4">
            <div class="col-md-2">Jenis Kelamin <small class="text-danger">*</small></div>
            <div class="col-md-4">
                <select name="gender" id="gender" class="form-control">
                    <option value="">Pilih Jenis Kelamin</option>
                    <option value="laki-laki" <?php echo e(old('gender', Auth::guard('recruitment')->user()->teacher->gender) == 'laki-laki' ? 'selected' : ''); ?>>Laki-Laki</option>
                    <option value="perempuan" <?php echo e(old('gender', Auth::guard('recruitment')->user()->teacher->gender) == 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>
        </div>

        <div class="form-group row align-items-center mb-4">
            <div class="col-md-2">Tempat & Tanggal Lahir <small class="text-danger">*</small></div>
            <div class="col-md-4"><input type="text" name="birthday_at" value="<?php echo e(old('birthday_at', Auth::guard('recruitment')->user()->teacher->birthday_at)); ?>" id="birthday_at" placeholder="Masukan tempat lahir anda" class="form-control"></div>
            <div class="col-md-4"><input type="date" name="birthday" value="<?php echo e(old('birthday', Auth::guard('recruitment')->user()->teacher->birthday)); ?>" id="birthday" placeholder="Masukan tanggal lahir anda" class="form-control"></div>
        </div>
        
        <div class="form-group row align-items-center mb-4">
            <div class="col-md-2">Alamat <small class="text-danger">*</small></div>
            <div class="col-md-4"><textarea name="address" id="address" rows="5" placeholder="Masukan alamat anda" class="form-control"><?php echo e(old('address', Auth::guard('recruitment')->user()->teacher->address)); ?></textarea></div>
        </div>

        <div class="form-group row align-items-center mb-4">
            <div class="col-md-2">No. Handphone <small class="text-danger">*</small></div>
            <div class="col-md-4"><input type="text" name="phone" id="phone" value="<?php echo e(old('phone', Auth::guard('recruitment')->user()->teacher->phone)); ?>" placeholder="62821xxxxxxx" class="form-control"></div>
        </div>
    </div>
    <div class="main-button">
        <button type="submit" class="btn btn-primary">Simpan</button>
        <?php if(Auth::guard('recruitment')->user()->recruitment->step > 1): ?>
            <a href="<?php echo e(route('recruitment.photo')); ?>" class="btn btn-success">Selanjutnya</a>
        <?php endif; ?>
    </div>
</form><?php /**PATH C:\xampp\htdocs\Laravel\sendikasih_sandika\resources\views/recruitment/dashboard/biodata/teacher.blade.php ENDPATH**/ ?>