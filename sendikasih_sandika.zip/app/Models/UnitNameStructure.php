<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UnitNameStructure extends Model
{
    use HasFactory;

    protected $table = 'unit_name_structures';

    public function list(){
        return $this->hasMany(UnitStructureItem::class);
    }
}
